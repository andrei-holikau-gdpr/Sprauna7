﻿using Bunit;
using Sprauna7Publish.BunitTests.Utilities;
using Sprauna7Publish.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprauna7Publish.BunitTests
{
    public class SimpleComponentForTestingTests
    {
        [Fact]
        public void TooltipTest()
        {
            // Arrange
            using var ctx = new TestContext();
            var moduleInterop = AddModuleInterop.BootstrapBlazorComponentsTooltip(ctx);
            var cut = ctx.RenderComponent<SimpleComponentForTesting>(
            // parameters => parameters
            //    .Add(p => p.BunitTest, false)
            );
            var paraElm = cut.Find(".sp-navlink-text");

            // Act
            var paraElmText = paraElm.TextContent;

            // Assert
            paraElmText.MarkupMatches("Figma");
        }
    }
}
