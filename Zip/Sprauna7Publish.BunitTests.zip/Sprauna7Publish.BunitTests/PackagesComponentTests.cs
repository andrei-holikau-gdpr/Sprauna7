﻿using AngleSharp.Dom;
using Bunit;
using Bunit.TestDoubles;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Plugins.DataStore.InMemory;
using Sprauna7Publish.BunitTests.Utilities;
using Sprauna7Publish.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.PurchasesUseCases;
using UseCases.UseCaseInterfaces;

namespace Sprauna7Publish.BunitTests
{
    public class PackagesComponentTests
    {
        [Fact]
        public void PackagesComponent_ViewTest()
        {
            // Arrange
            using var ctx = new TestContext();
            var moduleInterop = AddModuleInterop.BootstrapBlazorComponentsTooltip(ctx);

            var navMan = ctx.Services.GetRequiredService<EditPurchaseUseCase>();
            var navRep = ctx.Services.GetRequiredService<PurchaseInMemoryRepository>();
            var serviceEditPurchase = ctx.Services.GetRequiredService<EditPurchaseUseCase>();


            ctx.Services.AddSingleton<IEditPurchaseUseCase>(new EditPurchaseUseCase(navRep));

            var cut = ctx.RenderComponent<PackagesComponent>(
            // parameters => parameters
            //    .Add(p => p.BunitTest, false)
            );
            var paraElm = cut.Find("all-packages");

            // Act
            var paraElmText = paraElm.TextContent;

            // Assert
            Assert.NotNull(paraElmText);
        }
    }
}
